# Read Before Repeat

ထပ်မလုပ်ခင် ဖတ်ပါ

**ID:** COM-2026-BEAUTY-09  
**Format:** pack literacy film  
**Linked campaign:** CMP-2026-BEAUTY-09  

## Film Brief

**Tension:** Packaging can become only an aesthetic signal when users cannot easily find client-approved use, disposal, batch, label or care information.

**Objective:** Create a brand-safe, bilingual storytelling direction that supports an approved campaign route; no product, treatment, efficacy, safety, diagnostic, price, availability or outcome claim.

**Creative territory:** The pack can invite a clearer question

## 12-Frame Storyboard

| # | Time | Visual action | Camera | Audio | Text | Purpose |
|---:|---|---|---|---|---|---|
| 1 | 00:00–00:03 | Opening macro: a proposed/TBC beauty-world detail introduces “Read Before Repeat”. | Macro glide | Soft room tone | ZYNTH BEAUTY / proposed direction | Set the atmosphere without a product claim. |
| 2 | 00:03–00:06 | A human hand pauses before an ambiguous, fictional beauty cue. | Close handheld | One breath / fabric sound | A question can be beautiful. | Introduce tension. |
| 3 | 00:06–00:09 | Typography names the tension in controlled, non-medical language. | Static graphic overlay | Minimal tonal pulse | No claim. Start with clarity. | Protect claim boundary. |
| 4 | 00:09–00:13 | The protagonist chooses an information card, not a product outcome. | Over-shoulder | Paper fold | Read / confirm / ask. | Show informed choice. |
| 5 | 00:13–00:17 | A second participant adds a different perspective. | Two-shot | Soft conversational texture | Your routine, your terms. | Add community without testimonial. |
| 6 | 00:17–00:21 | A proposed/TBC brand-world cue becomes an abstract colour/texture/light composition. | Slow orbit | Warm tonal swell | Beauty without pressure. | Express creative territory. |
| 7 | 00:21–00:25 | A protected consent prompt appears on a fictional interface. | Screen insert | Single notification tone | Choose your next step. | Show consent gate. |
| 8 | 00:25–00:29 | Vertical-safe composition reframes the moment for social cutdown. | 9:16 crop move | Rhythmic edit tick | For TikTok / social: asset route TBC | Signal versioning, not approval. |
| 9 | 00:29–00:33 | The human action resolves into a calm, open-ended gesture. | Medium slow motion | Room tone returns | No promise. Just a clearer path. | Resolve without efficacy. |
| 10 | 00:33–00:37 | Bilingual line appears with Myanmar title. | Graphic dissolve | Soft music rise | ထပ်မလုပ်ခင် ဖတ်ပါ | Land bilingual identity. |
| 11 | 00:37–00:42 | Client-approved legal/claims placeholder panel replaces any commercial claim. | Clean end-card hold | Audio fades | Product / price / availability / claim TBC | Show approval requirement. |
| 12 | 00:42–00:45 | Final CTA directs to approved information, booking or retailer-assistance destination. | Static end card | Single chime | Client-approved CTA required | End with gated action. |

## Production, Social Versioning & Claims Gate

> This is a creative storyboard direction only. Script, product facts, claims, pack shots, cast, location, music, subtitles, platform formats, safety, privacy, rights and end-card CTA require written client approval.
